//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.lingyi.autiovideo.test.inter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public interface IFragment {


    View initView(LayoutInflater var1, ViewGroup var2, Bundle var3);

    void initData(Bundle var1);

}
